
//导入外部模块内容
// 2 metodo
// 1
const {a,x} = require('./3-1.a')
console.log(a,x);
// 2
console.log(require('./3-1.a'))