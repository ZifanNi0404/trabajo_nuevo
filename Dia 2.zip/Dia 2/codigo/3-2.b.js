let c = 3
let x = 12