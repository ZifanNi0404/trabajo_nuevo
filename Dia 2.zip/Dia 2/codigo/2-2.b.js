let c = 3
let x = 12
export { c, x }