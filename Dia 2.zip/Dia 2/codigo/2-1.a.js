export let a = 1
export let x = 10

function fn() {
return a + x
}

//export { a, x } //将a和x这两个变量导处去 

//两种定义方式


export default fn //默认导出