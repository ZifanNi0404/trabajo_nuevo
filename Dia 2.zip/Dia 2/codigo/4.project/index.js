//如何使用第三方包
//1,确认一下js运行环境
console.log(require('lodash'));



const _ =require('lodash') 
let arr = [1,2,3]
_.fill(arr,'peiqi')
console.log(arr);