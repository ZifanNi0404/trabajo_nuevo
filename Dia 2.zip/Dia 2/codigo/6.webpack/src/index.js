//所有js主入口
const { sum } = require('./utils/index.js')
import './test.css'
console.log(sum(1, 2));